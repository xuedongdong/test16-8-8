<?php
return array(
	//'配置项'=>'配置值'
);